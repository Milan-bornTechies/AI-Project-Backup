import logging
from django.shortcuts import render, redirect
from .models import User, WorkSpace, Uploadfiles, Onboard, Admin_user, Pricing, Feedback, Training_Videos_Pricing
from django.conf import settings
from django.core.mail import send_mail
import random
import requests
import json
import openai
import os
from django.urls import reverse
from moviepy.editor import VideoFileClip, concatenate_videoclips, AudioFileClip
from moviepy.video.fx.all import resize
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
from datetime import datetime, timedelta
from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from gtts import gTTS
from django.core.files import File
from django.db.models import Count
from django.contrib import messages
import re
import stripe
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required
import time
import sys
from django.contrib.auth import logout as auth_logout
from django.core.files.storage import FileSystemStorage
from .forms import EmailForm
from django.core.cache import cache
from django.utils import timezone
from django.shortcuts import render, get_object_or_404
from .models import Post,Platform, YouTubeBlog, InstagramBlog, TikTokBlog, FacebookBlog, LinkedInBlog


logging.basicConfig(level=logging.INFO)  # Set to logging.DEBUG for more detailed logs

PEXELS_API_KEY = "ypeI3O5kOBaEaADVqRmmxrd0E9JYkg8ztdRerqANZQLbPwLc4KfKXbj1"
# Replace with your OpenAI API key
API_KEY = "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"
openai.api_key = API_KEY  # Set the OpenAI API key

# Create your views here.
def index(request):
    return render(request, 'index.html')

def signup(request):
    if request.method == 'POST':
        email = request.POST['email']
        # Generate a verification code (You may use a library like secrets for this)
        verification_code = random.randint(100000, 999999)
        email_from = settings.EMAIL_HOST_USER
        send_mail('Verification Code', f'Your verification code is: {verification_code}', email_from, [email])
        verification_code_str = str(verification_code)
        integer_to_insert = random.randint(0, 9)
        modified_code_str = verification_code_str[:2] + str(integer_to_insert) + verification_code_str[2:]
        # Save the verification code somewhere associated with the user (like a separate model)
        # For simplicity, I'll just use the session for this example
        return render(request, 'verify_otp.html', {'email': email, 'otp': modified_code_str})
    return render(request, 'signup.html')


def verify_otp(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        uotp = request.POST.get('uotp')
        newOtp = uotp[:2] + uotp[3:]
        otp = request.POST.get('otp')

        if otp == newOtp:
            try:
                user = User.objects.get(email=email)
                user.pswd = otp
                user_pk = user.pk
                user.save()
                request.session['email'] = user.email

                # Check for redirect_from session variable
                redirect_from = request.session.pop('redirect_from', None)
                if redirect_from == 'trainingVideos':
                    try:
                        training_data = Training_Videos_Pricing.objects.get(user=user)
                        pricing_value_training = training_data.plan_name

                        if pricing_value_training == 'Free':
                            base_dir = os.path.join(settings.BASE_DIR, 'myapp', 'static', 'folders', 'videos')
                            folders = [f for f in os.listdir(base_dir) if os.path.isdir(os.path.join(base_dir, f))]

                            # Sort folders: S01, S02, ..., OTHERS
                            folders.sort()
                            if 'OTHERS' in folders:
                                folders.append(folders.pop(folders.index('OTHERS')))
                            return render(request, "training.html", {'user': user, 'folders': folders})
                        else:
                            return redirect('trainingVideos')
                    except Training_Videos_Pricing.DoesNotExist:
                        messages.error(request, 'Please Purchase Plan From this Service.')
                        return redirect('trainingVideos')
                else:
                    return redirect(reverse('work_space', kwargs={'pk': user_pk}))
            except User.DoesNotExist:
                user = User.objects.create(
                    email=email,
                    pswd=otp,
                )
                user_pk = user.pk
                request.session['email'] = user.email

                # Check for redirect_from session variable
                redirect_from = request.session.pop('redirect_from', None)
                if redirect_from == 'trainingVideos':
                    return redirect('trainingVideos')
                else:
                    return redirect(reverse('onboard', kwargs={'pk': user_pk}))
        else:
            msg1 = "OTP doesn't match!!!"
            return render(request, 'verify_otp.html', {'msg1': msg1, 'email': email, 'otp': uotp})
    else:
        return render(request, 'verify_otp.html')
        
def onboard(request, pk):

    try:
        # Get the user based on the email in the session
        user = User.objects.get(email=request.session['email'])

    except:
        # Handle the case where the user does not exist
        return redirect('login')
    
    if request.method == "POST":
        try:
            # Use the user session variables to get the user
            user = User.objects.get(email=request.session['email'])
            user.name = request.POST['workspace_username']
            user.save()
            # Ensure that the user exists and get other form data
            workspace_username = request.POST['workspace_username']
            workspace_name = request.POST['workspace_name']

            # Create an Onboard instance associated with the user
            onboard = Onboard.objects.create(
                user=user,
                workspace_username=workspace_username,
                workspace_name=workspace_name
            )

            msg = "Welcome in AI Video"

            # Redirect to the work_space page after onboard details are submitted
            return redirect(reverse('work_space', kwargs={'pk': pk}))

        except Exception as e:
            msg1 = f"Error: {e}"
            return render(request, 'onboard.html', {'msg1': msg1})

    else:
        msg1 = "Give some perfect information for our reference."
        return render(request, 'onboard.html', {'msg1': msg1})

def resend_code(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        verification_code = random.randint(100000, 999999)
        email_from = settings.EMAIL_HOST_USER
        send_mail('Verification Code', f'Your verification code is: {verification_code}', email_from, [email])
        verification_code_str = str(verification_code)
        integer_to_insert = random.randint(0, 9)
        modified_code_str = verification_code_str[:2] + str(integer_to_insert) + verification_code_str[2:]
        return JsonResponse({'message': 'Verification code resent.', 'new_otp': modified_code_str})
    return JsonResponse({'message': 'Invalid request'}, status=400)        

def login(request):
    if request.method == 'POST':
        email = request.POST['email']
        # Generate a verification code (You may use a library like secrets for this)
        verification_code = random.randint(100000, 999999)
        email_from = settings.EMAIL_HOST_USER
        send_mail('Verification Code', f'Your verification code is: {verification_code}', email_from, [email])
        verification_code_str = str(verification_code)
        integer_to_insert = random.randint(0, 9)
        modified_code_str = verification_code_str[:2] + str(integer_to_insert) + verification_code_str[2:]
        # Save the verification code somewhere associated with the user (like a separate model)
        # For simplicity, I'll just use the session for this example
        return render(request, 'verify_otp.html', {'email': email, 'otp': modified_code_str})
    return render(request, 'login.html')

def logout(request):
    
    auth_logout(request)
    request.session.flush()

    if 'email' in request.session:
       del request.session['email']

    return redirect('login')

# def fpswd(request):
#     if request.method == "POST":
#         try:
#             user = User.objects.get(email=request.POST['email'])
#             subject = 'Forgot Password OTP'
#             otp = random.randint(100000, 999999)
#             message = f'Hi {user.name}, thank you for registering in my app, your OTP is: {otp}'
#             email_from = settings.EMAIL_HOST_USER
#             recipient_list = [user.email, ]
#             send_mail(subject, message, email_from, recipient_list)
#             return render(request, 'verify_otp.html', {'email': user.email, 'otp': str(otp)})
#         except User.DoesNotExist:
#             msg1 = "you are not a registered user..."
#             return render(request, 'fpswd.html', {'msg1': msg1})
#     else:
#         return render(request, 'fpswd.html')

# def set_pswd(request):
#     if request.method == "POST":
#         email = request.POST['email']
#         npswd = request.POST['npswd']
#         cnpswd = request.POST['cnpswd']
#         if npswd == cnpswd:
#             user = User.objects.get(email=email)
#             user.pswd = npswd
#             user.save()
#             return redirect('login')
#         else:
#             msg1 = "password and confirm password do not match..."
#             return render(request, 'set_pswd.html', {'msg1': msg1})
#     else:
#         return render(request, 'set_pswd.html')

def generate_text(user_input_text, Eden_AI):
    headers = {"Authorization": f"Bearer {Eden_AI}"}
    url = "https://api.edenai.run/v2/text/generation"
    payload = {
        "providers": "openai,cohere",
        "text": user_input_text,
        "temperature": 0.2,
        "max_tokens": 1000
    }
    try:
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        result = response.json()
        generated_text = result.get('openai', {}).get('generated_text', None)
        if generated_text:
            return generated_text.replace("#", "").replace("*", "")
        else:
            print("Error: Unable to fetch generated text from Eden AI.")
            return None
    except requests.exceptions.RequestException as e:
        print(f"Error in text generation process: {e}")
        return None


def generate_shorts_text(request, user_input_text, Eden_AI,video_duration_time):
    headers = {"Authorization": f"Bearer {Eden_AI}"}
    url = "https://api.edenai.run/v2/text/generation"
    payload = {
        "providers": "openai",
        "model": "gemini-pro",
        "text": user_input_text,
        "temperature": 0.1,
        "max_tokens": video_duration_time
    }
    try:
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        result = response.json()
        generate_text = result.get('openai', {}).get('generated_text', None)
        if generate_text:
            generated_text = generate_text.replace("#", "").replace("*", "")
            sentences = generated_text.split(".")
            # Remove the last incomplete sentence
            if not sentences[-1].endswith("."):
                generated_text = ". ".join(sentences[:-1])
            return generated_text
        else:
            error_message = "There was an issue generating text. Please try again later."
            return render(request, 'error_page.html', {'error_message': error_message})
    except:
        error_message = "There was an issue generating text. Please try again later."
        return render(request, 'error_page.html', {'error_message': error_message})
    
def create_folder(user_input_text):
    # Replace spaces with underscores
    folder_name = user_input_text.replace(" ", "_")
    base_folder_path = os.path.join(settings.MEDIA_ROOT, folder_name)

    # Check if the folder already exists
    if not os.path.exists(base_folder_path):
        os.makedirs(base_folder_path, exist_ok=True)
        return base_folder_path

    # If the folder already exists, append a suffix
    suffix = 1
    while True:
        folder_path = os.path.join(
            settings.MEDIA_ROOT, f"{folder_name}_{suffix}")
        if not os.path.exists(folder_path):
            os.makedirs(folder_path, exist_ok=True)
            return folder_path
        suffix += 1

def merge_videos(video_urls, folder_path, target_duration):
    video_clips = []
    common_width, common_height = None, None
    total_duration = 0

    while total_duration < target_duration:
        for i, video_url in enumerate(video_urls):
            if i >= 11 or total_duration >= target_duration:
                break

            video_response = requests.get(video_url, timeout=10)
            video_response.raise_for_status()
            video_filename = os.path.join(folder_path, f"output_video_{i + 1}.mp4")
            # video_file_name = os.path.basename(video_url).split('?')[0]
            video_file_path = os.path.join(folder_path, video_filename)

            with open(video_file_path, "wb") as f:
                f.write(video_response.content)

            video_clip = VideoFileClip(video_file_path)
            if common_width is None and common_height is None:
                common_width, common_height = video_clip.size
            video_clip_resized = video_clip.resize((common_width, common_height))
            video_clips.append(video_clip_resized)

            total_duration += video_clip.duration

    # Trim the last video clip to match the target duration
    if total_duration > target_duration:
        last_clip_duration = video_clips[-1].duration
        excess_duration = total_duration - target_duration
        trimmed_last_clip = video_clips[-1].subclip(0, last_clip_duration - excess_duration)
        video_clips[-1] = trimmed_last_clip

    merged_video_path = os.path.join(folder_path, "merged_video.mp4")

    try:
        final_clip = concatenate_videoclips(video_clips, method="compose")
        final_clip.write_videofile(
            merged_video_path, codec="libx264", fps=24, logger=None
        )
    except Exception as e:
        print(f"Error merging videos: {e}")
        raise

    return merged_video_path


def merge_audio_and_video(audio_path, video_path, output_path):
    audio_clip = AudioFileClip(audio_path)
    video_clip = VideoFileClip(video_path)
    # Ensure audio duration matches or is shorter than video duration
    audio_duration = min(audio_clip.duration, video_clip.duration)
    audio_clip = audio_clip.subclip(0, audio_duration)
    # Set the duration of the video clip to match the audio duration
    video_clip = video_clip.set_duration(audio_duration)
    # Combine audio and video
    final_clip = video_clip.set_audio(audio_clip)
    # Write the merged audio and video to a file
    final_clip.write_videofile(
        output_path, codec="libx264", fps=24, logger=None)
    return output_path

def generate_audio(text, folder_path, gender, Eden_AI, aiServices_select_from_form, useVoiceof_form,audio_speed_rate):
    headers = {
        "Authorization": f"Bearer {Eden_AI}",
        "Content-Type": "application/json"
    }

    url = "https://api.edenai.run/v2/audio/text_to_speech"
    
    # Combine aiServices_select_from_form and useVoiceof_form to create the providers string
    provider = f"{aiServices_select_from_form}/{useVoiceof_form}"
    
    payload = {
        "providers": provider,
        "language": "en",  # Adjust language as needed
        "option": gender.upper(),  # Dynamically use gender
        "text": text,
        "rate":audio_speed_rate,
    }

    try:
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()  # Raise error if the request failed
        result = response.json()

        # Ensure that the response contains the expected provider key
        if provider in result:
            audio_url = result[provider].get('audio_resource_url')
            print(audio_url)
            if audio_url:
                # Fetch the audio content
                audio_response = requests.get(audio_url)
                audio_data = audio_response.content
                
                # Handle the output path
                audio_output_path = folder_path if 'mp3' in folder_path else os.path.join(folder_path, "output.mp3")
                
                # Write the audio content to the file
                with open(audio_output_path, 'wb') as audio_file:
                    audio_file.write(audio_data)
                
                return audio_output_path
            else:
                print("Audio URL not found")
                return None
        else:
            print(f"Error: No result for provider {provider}")
            return None

    except requests.exceptions.RequestException as e:
        print(f"Error: {e}")
        return None

def keyword_extraction(user_input_text, Eden_AI):
    headers = {"Authorization": f"Bearer {Eden_AI}"}

    url = "https://api.edenai.run/v2/text/keyword_extraction"
    payload = {
        "providers": "amazon,microsoft",
        "language": "en",
        "text": user_input_text
    }

    response = requests.post(url, json=payload, headers=headers)
    print(response.text)  # or use logging

    result = json.loads(response.text)

    # Extract keywords from the 'items' list for each provider
    keywords = [item['keyword'] for provider_data in result.values() if 'items' in provider_data for item in provider_data['items']]

    # Remove duplicates by converting the list to a set and back to a list
    unique_keywords = list(set(keywords))

    return unique_keywords

def get_three_min_video_from_pexels(user_input_text):
    try:
        api_key = 'ny88hc8urgf857vganyqsfqf'
        api_secret = 'jJTfqEMmCpuja7XYejV4'

        base_url = 'https://api.gettyimages.com'
        endpoint = '/v3/search/videos/creative'

        headers = {
            'Api-Key': api_key,
            'Api-Secret': api_secret,
        }
        params = {
            'phrase': user_input_text,
            'page': 1,
            'page_size': 10,
            'min_clip_length': 20
        }
        url = f'{base_url}{endpoint}'
        response = requests.get(url, headers=headers, params=params)

        response.raise_for_status()
        data = response.json()

        # Extract 'preview' URIs
        preview_uris = [size['uri'] for video in data.get('videos', []) for size in video.get('display_sizes', []) if size.get('name') == 'preview']
        # print(preview_uris)
        return preview_uris[:10]  # Return all the available videos
    except requests.exceptions.RequestException as e:
        print(f"Error fetching videos from Pexels: {e}")
        return []
    
def get_three_min_video_from_istock(newprompt):
    try:
        api_key = 'ny88hc8urgf857vganyqsfqf'
        api_secret = 'jJTfqEMmCpuja7XYejV4'

        base_url = 'https://api.gettyimages.com'
        endpoint = '/v3/search/videos/creative'

        headers = {
            'Api-Key': api_key,
            'Api-Secret': api_secret,
        }
        params = {
            'phrase': newprompt,
            'page': 1,
            'page_size': 10,
            'min_clip_length': 10
        }
        url = f'{base_url}{endpoint}'
        response = requests.get(url, headers=headers, params=params)

        response.raise_for_status()
        data = response.json()

        # Extract 'preview' URIs
        preview_uris = [size['uri'] for video in data.get('videos', []) for size in video.get('display_sizes', []) if size.get('name') == 'preview']
        # print(preview_uris)
        return preview_uris[:5]  # Return all the available videos
    except requests.exceptions.RequestException as e:
        print(f"Error fetching videos from Pexels: {e}")
        return []

def get_shorts_from_pexels(user_input_text):
    try:
        api_key = 'ny88hc8urgf857vganyqsfqf'
        api_secret = 'jJTfqEMmCpuja7XYejV4'

        base_url = 'https://api.gettyimages.com'
        endpoint = '/v3/search/videos/creative'

        headers = {
            'Api-Key': api_key,
            'Api-Secret': api_secret,
        }
        params = {
            'phrase': user_input_text,
            'page': 1,
            'page_size': 10,
            'min_clip_length': 15,
            'aspect_ratios': ["9:16"] 
        }
        url = f'{base_url}{endpoint}'
        response = requests.get(url, headers=headers, params=params)

        response.raise_for_status()
        data = response.json()
        # Extract 'preview' URIs
        preview_uris = [size['uri'] for video in data.get('videos', []) for size in video.get('display_sizes', []) if size.get('name') == 'preview']
        # print(preview_uris)
        return preview_uris[:5]  # Return all the available videos
    except requests.exceptions.RequestException as e:
        print(f"Error fetching videos from Pexels: {e}")
        return []

def get_shorts_from_istock(prompt):
    try:
        api_key = 'ny88hc8urgf857vganyqsfqf'
        api_secret = 'jJTfqEMmCpuja7XYejV4'

        base_url = 'https://api.gettyimages.com'
        endpoint = '/v3/search/videos/creative'

        headers = {
            'Api-Key': api_key,
            'Api-Secret': api_secret,
        }
        params = {
            'phrase': prompt,
            'page': 1,
            'page_size': 10,
            'min_clip_length': 15,
            'aspect_ratios': ["9:16"] 
        }
        url = f'{base_url}{endpoint}'
        response = requests.get(url, headers=headers, params=params)

        response.raise_for_status()
        data = response.json()
        # Extract 'preview' URIs
        preview_uris = [size['uri'] for video in data.get('videos', []) for size in video.get('display_sizes', []) if size.get('name') == 'preview']
        # print(preview_uris)
        return preview_uris[:3]  # Return all the available videos
    except requests.exceptions.RequestException as e:
        print(f"Error fetching videos from Pexels: {e}")
        return []

def generate_audio_from_video(video_path, output_audio_path):
    try:
        video_clip = VideoFileClip(video_path)
        audio_clip = video_clip.audio
        audio_clip.write_audiofile(output_audio_path)
        video_clip.close()
        return output_audio_path
    except Exception as e:
        print(f"Error generating audio from video: {e}")
        return None

def split_video_into_segments_with_audio(video_path, output_folder, segment_duration=20):
    os.makedirs(output_folder, exist_ok=True)

    video_clip = VideoFileClip(video_path)
    total_duration = video_clip.duration
    num_segments = int(total_duration // segment_duration)

    segment_urls = []
    segment_audio_paths = []

    for i in range(num_segments):
        start_time = i * segment_duration
        end_time = (i + 1) * segment_duration
        segment = video_clip.subclip(start_time, end_time)

        segment_filename = f"segment_{i + 1}.mp4"
        segment_filepath = os.path.join(output_folder, segment_filename)
        segment.write_videofile(segment_filepath, codec="libx264", audio_codec="aac")

        # Generate audio from the video segment
        output_audio_path = os.path.join(output_folder, f"segment_{i + 1}.mp3")
        audio_path = generate_audio_from_video(segment_filepath, output_audio_path)
        
        if audio_path:
            # Construct the URL for the segment audio using MEDIA_URL
            relative_audio_path = os.path.relpath(audio_path, settings.MEDIA_ROOT)
            segment_audio_paths.append(os.path.join(settings.MEDIA_URL, relative_audio_path))

        # Construct the URL for the segment video using MEDIA_URL
        relative_path = os.path.relpath(segment_filepath, settings.MEDIA_ROOT)
        segment_urls.append(os.path.join(settings.MEDIA_URL, relative_path))

    # Handle the remaining duration
    remaining_duration = total_duration % segment_duration
    if remaining_duration > 0:
        start_time = num_segments * segment_duration
        remaining_segment = video_clip.subclip(start_time, total_duration)
        remaining_filename = f"segment_{num_segments + 1}.mp4"
        remaining_filepath = os.path.join(output_folder, remaining_filename)
        remaining_segment.write_videofile(
            remaining_filepath, codec="libx264", audio_codec="aac")

        # Generate audio from the remaining segment
        output_audio_path = os.path.join(output_folder, f"segment_{num_segments + 1}.mp3")
        audio_path = generate_audio_from_video(remaining_filepath, output_audio_path)

        if audio_path:
            # Construct the URL for the remaining segment audio using MEDIA_URL
            relative_audio_path = os.path.relpath(audio_path, settings.MEDIA_ROOT)
            segment_audio_paths.append(os.path.join(settings.MEDIA_URL, relative_audio_path))

        # Construct the URL for the remaining segment using MEDIA_URL
        relative_path = os.path.relpath(
            remaining_filepath, settings.MEDIA_ROOT)
        remaining_segment_url = os.path.join(settings.MEDIA_URL, relative_path)
        segment_urls.append(remaining_segment_url)

    video_clip.close()

    return segment_audio_paths

def split_video_into_segments(video_path, output_folder, segment_duration=20):
    os.makedirs(output_folder, exist_ok=True)

    video_clip = VideoFileClip(video_path)
    total_duration = video_clip.duration
    num_segments = int(total_duration // segment_duration)

    segment_urls = []

    for i in range(num_segments):
        start_time = i * segment_duration
        end_time = (i + 1) * segment_duration
        segment = video_clip.subclip(start_time, end_time)

        segment_filename = f"segment_{i + 1}.mp4"
        segment_filepath = os.path.join(output_folder, segment_filename)
        segment.write_videofile(
            segment_filepath, codec="libx264", audio_codec="aac")

        # Construct the URL for the segment using MEDIA_URL
        relative_path = os.path.relpath(segment_filepath, settings.MEDIA_ROOT)
        segment_url = os.path.join(settings.MEDIA_URL, relative_path)
        segment_urls.append(segment_url)

    # Handle the remaining duration
    remaining_duration = total_duration % segment_duration
    if remaining_duration > 0:
        start_time = num_segments * segment_duration
        remaining_segment = video_clip.subclip(start_time, total_duration)
        remaining_filename = f"segment_{num_segments + 1}.mp4"
        remaining_filepath = os.path.join(output_folder, remaining_filename)
        remaining_segment.write_videofile(
            remaining_filepath, codec="libx264", audio_codec="aac")

        # Construct the URL for the remaining segment using MEDIA_URL
        relative_path = os.path.relpath(
            remaining_filepath, settings.MEDIA_ROOT)
        remaining_segment_url = os.path.join(settings.MEDIA_URL, relative_path)
        segment_urls.append(remaining_segment_url)

    video_clip.close()

    return segment_urls

def transcribe_audio_to_text(audio_file_path):
    try:
        with open(audio_file_path, "rb") as audio_file:
            response = openai.Audio.transcribe(
                file=audio_file,
                model="whisper-1",
                response_format="text",
                language="en",  # Use ISO-639-1 format for English
            )

            # Assuming response is a string containing the transcribed text
            transcript = response

            # Create a counter to generate unique filenames
            counter = 1

            # Save the transcript to a text file with a unique name
            while True:
                text_file_name = f"transcript_{counter}.txt"
                text_file_path = os.path.join(os.path.dirname(audio_file_path), text_file_name)
                if not os.path.exists(text_file_path):
                    break
                counter += 1

            with open(text_file_path, "w") as text_file:
                text_file.write(transcript)
            return text_file_path
    except Exception as e:
        print(f"Error transcribing audio to text: {e}")
        return None    
    
def language_detection(user_input_texts, Eden_AI):
    try:
        headers = {"Authorization": f"Bearer {Eden_AI}"}
        url = "https://api.edenai.run/v2/translation/language_detection"
        payload = {
            "providers": "openai",
            "text": user_input_texts,
        }

        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()  # Raises an exception for 4XX/5XX errors

        result = response.json()  # Use .json() instead of json.loads(response.text)
        
        return result['openai']['items'][0]['language']
    
    except (requests.exceptions.RequestException, KeyError, IndexError) as e:
        print(f"Error occurred: {e}")
        return None

def work_space(request, pk):
    segment_urls = []
    segment_texts = []
    video_urls = []
    shorts_option_selected = False
    Eden_AI = settings.EDEN_AI_API_KEY


    try:
        user = User.objects.get(email=request.session['email'])
        onboard = Onboard.objects.get(user=user)
        workspace_name = onboard.workspace_name

    except User.DoesNotExist:
        return redirect('login')
    if pk is None:
        return redirect('index')

    if request.method == 'POST':

        user_pricing = Pricing.objects.filter(user=user).first()
        
        if user_pricing:
            user_plan_end_date = user_pricing.end_date
            today_date = datetime.now().date()
            if user_plan_end_date == today_date:
                name_of_plan = "Free"
            else:
                price_of_plan = user_pricing.price_of_plan
                if price_of_plan == 500:
                    name_of_plan = "Max Yearly"
                elif price_of_plan == 200:
                    name_of_plan = "Plus Yearly"
                elif  price_of_plan == 55:
                    name_of_plan = "Max Monthly"    
                elif  price_of_plan == 25:
                    name_of_plan = "Plus Monthly"
        else:
            name_of_plan = "Free"
                
        video_duration_time = int(request.POST.get('form-video-duration', 0))
        user_input_form_text = request.POST.get('form-message')
        language_select_from_form = request.POST.get('form-language-option')
        voice_select_from_form = request.POST.get('form-voice-option')
        aiServices_select_from_form = request.POST.get('form-aiservices')  
        useVoiceof_form = request.POST.get('form-use-voice-of')

        if video_duration_time == 120:
            audio_speed_rate = 10
        elif video_duration_time == 180:
            audio_speed_rate = 20
        else:
            audio_speed_rate = 0  
         
        if user_input_form_text:
            user_input_texts = user_input_form_text
        else:
            user_input_texts = request.POST.get('message', '')
            
        detectLanguage = language_detection(user_input_texts,Eden_AI) 
        
        if detectLanguage:                    
            if detectLanguage == 'en':
                translated_text =  user_input_texts
            else :
                translated_text = translate_to_english(user_input_texts, detectLanguage, Eden_AI)
        else:
            error_message = "There was an issue with Detected Language. Please try again later."
            return render(request, 'error_page.html', {'error_message': error_message, 'pk': pk}) 
                
        user_input_text = re.sub(r'[?/!#\$]', '', translated_text)
        new_prompt = keyword_extraction(user_input_text, Eden_AI)
        
        number_of_elements = len(new_prompt)
        
        selected_option = request.POST.get('youtube-option')

        generated_text = generate_shorts_text(request,user_input_text, Eden_AI,video_duration_time)

        #text is generated or not
        if generated_text:  
            if language_select_from_form == 'en':
                translate_text_inDetected_language = generated_text
            else:
                translate_text_inDetected_language = translate_to_detected_language(generated_text, language_select_from_form, Eden_AI)
        
            if translate_text_inDetected_language:
                sentences = translate_text_inDetected_language.split('.')
            else:
                error_message = "There was an issue with Translation text to Detected Language. Please try again later."
                return render(request, 'error_page.html', {'error_message': error_message, 'pk': pk})
            
            for i in range(0, len(sentences), 5):
                group = '.'.join(sentences[i:i+5])
                segment_texts.append(group)
            segment_texts = [text.replace("\n", "")+'.' for text in segment_texts]
                
            #text is divided into segments or not
            if segment_texts:
                folder_path = create_folder(user_input_text)
                if selected_option == "explainer":
                    if number_of_elements > 1:
                        video_urls = [url for prompt in new_prompt for url in get_three_min_video_from_istock(prompt)]
                    else:
                        video_urls = get_three_min_video_from_pexels(user_input_text)
                elif selected_option == "shorts":
                    shorts_option_selected = True
                    if number_of_elements > 1:
                        video_urls = [url for prompt in new_prompt for url in get_shorts_from_istock(prompt)]
                    else:
                        video_urls = get_shorts_from_pexels(user_input_text)

                #video are fetched or not from istock
                if video_urls:
                    gender = voice_select_from_form
                                        
                    generated_audio_path = generate_audio(translate_text_inDetected_language, folder_path, gender, Eden_AI,aiServices_select_from_form,useVoiceof_form,audio_speed_rate)                      
                                        
                    #audio is generated or not
                    if generated_audio_path:
                        # Initialize merged_audio_and_video_path to None
                        merged_audio_and_video_path = None


                        # Save the generated text and video URL to the WorkSpace model
                        work_space_entry = WorkSpace.objects.create(
                            user=user,
                            message=user_input_text,
                            gender=gender,
                            generated_text=generated_text,
                            video_option_selected=selected_option,
                            video_url=merged_audio_and_video_path,  # Change this to the actual video URL
                            created_at=datetime.now().date()
                        )

                        target_duration = 180
                        merged_video_path = merge_videos(video_urls, folder_path, target_duration)
                        
                        #merging video
                        if merged_video_path:
                            # Merge audio and video
                            output_path = os.path.join(folder_path, f"{user_input_text}.mp4")
                            merged_audio_and_video_path = merge_audio_and_video(generated_audio_path, merged_video_path,
                                                                                output_path)
                            relative_path = os.path.relpath(merged_audio_and_video_path, settings.MEDIA_ROOT)
                            
                            #merging video or audio
                            if merged_audio_and_video_path:
                                output_folder = os.path.join(folder_path, 'video_segments')
                                segment_urls = split_video_into_segments(
                                    merged_audio_and_video_path, output_folder, segment_duration=20)
                                segment_audio_urls = split_video_into_segments_with_audio(
                                    merged_audio_and_video_path, output_folder, segment_duration=20)

                                #segmented into texts and urls   
                                if segment_urls and segment_texts:

                                    upload_files_entry = Uploadfiles.objects.create(
                                        user=user,
                                        workspace=work_space_entry,
                                        segment_url_1=segment_urls[0] if segment_urls and len(segment_urls) > 0 else None,
                                        segment_url_2=segment_urls[1] if segment_urls and len(segment_urls) > 1 else None,
                                        segment_url_3=segment_urls[2] if segment_urls and len(segment_urls) > 2 else None,
                                        segment_url_4=segment_urls[3] if segment_urls and len(segment_urls) > 3 else None,
                                        segment_url_5=segment_urls[4] if segment_urls and len(segment_urls) > 4 else None,
                                        segment_url_6=segment_urls[5] if segment_urls and len(segment_urls) > 5 else None,
                                        segment_url_7=segment_urls[6] if segment_urls and len(segment_urls) > 6 else None,
                                        segment_url_8=segment_urls[7] if segment_urls and len(segment_urls) > 7 else None,
                                        segment_url_9=segment_urls[8] if segment_urls and len(segment_urls) > 8 else None,
                                        segment_text_1=segment_texts[0] if segment_texts and len(segment_texts) > 0 else None,
                                        segment_text_2=segment_texts[1] if segment_texts and len(segment_texts) > 1 else None,
                                        segment_text_3=segment_texts[2] if segment_texts and len(segment_texts) > 2 else None,
                                        segment_text_4=segment_texts[3] if segment_texts and len(segment_texts) > 3 else None,
                                        segment_text_5=segment_texts[4] if segment_texts and len(segment_texts) > 4 else None,
                                        segment_text_6=segment_texts[5] if segment_texts and len(segment_texts) > 5 else None,
                                        segment_text_7=segment_texts[6] if segment_texts and len(segment_texts) > 6 else None,
                                        segment_text_8=segment_texts[7] if segment_texts and len(segment_texts) > 7 else None,
                                        segment_text_9=segment_texts[8] if segment_texts and len(segment_texts) > 8 else None,
                                    )
                                    # Update the WorkSpace model with the actual video URL
                                    work_space_entry.video_url = os.path.join(settings.MEDIA_URL, relative_path)
                                    work_space_entry.upload_files_entry = upload_files_entry
                                    work_space_entry.save()

                                    user_work_space_entries = WorkSpace.objects.filter(user=user).order_by('-created_at')
                                    user_upload_files = Uploadfiles.objects.filter(user=user)
                                    return render(request, 'work_space.html', {
                                        'pk': pk,
                                        'user': user,
                                        'generated_text': generated_text,
                                        'generated_audio_path': generated_audio_path,
                                        'video_urls': video_urls,
                                        'user_input_text': user_input_text,
                                        'work_space_entry': work_space_entry,
                                        # 'video_filenames': video_filenames,
                                        'merged_video_path': merged_video_path,
                                        'merged_audio_and_video_path': os.path.join(settings.MEDIA_URL, relative_path),
                                        'user_work_space_entries': user_work_space_entries,
                                        'segment_urls': segment_urls,
                                        'segment_texts': segment_texts,  # Pass user's WorkSpace entries to the template
                                        'workspace_name': workspace_name,
                                        'name_of_plan' : name_of_plan,
                                        'shorts_option_selected': shorts_option_selected,

                                    })
                                else:
                                    error_message = "There was an issue segmented video and text. Please try again later."
                                    return render(request, 'error_page.html', {'error_message': error_message, 'pk': pk})
                            else:
                                error_message = "There was an issue merged video with audio. Please try again later."
                                return render(request, 'error_page.html', {'error_message': error_message, 'pk': pk})
                        else:
                            error_message = "There was an issue merged video. Please try again later."
                            return render(request, 'error_page.html', {'error_message': error_message, 'pk': pk})
                    else:
                        error_message = "There was an issue audio. Please try again later."
                        return render(request, 'error_page.html', {'error_message': error_message, 'pk': pk})
                else:
                    error_message = "There was an issue Video URLS. Please try again later."
                    return render(request, 'error_page.html', {'error_message': error_message, 'pk': pk}) 
            else:
                error_message = "There was an issue Segmented text. Please try again later."
                return render(request, 'error_page.html', {'error_message': error_message, 'pk': pk})
        else:
            error_message = "There was an issue generating text. Please try again later."
            return render(request, 'error_page.html', {'error_message': error_message, 'pk': pk})
    else:
        user_work_space_entries = WorkSpace.objects.filter(user=user)
        user_upload_files = Uploadfiles.objects.filter(user=user)
        user_pricing = Pricing.objects.filter(user=user).first()
        # Check if the user has any pricing data

        if user_pricing:
            user_plan_end_date = user_pricing.end_date
            today_date = datetime.now().date()
            if user_plan_end_date == today_date:
                name_of_plan = "Free"
            else:
                price_of_plan = user_pricing.price_of_plan
                if price_of_plan == 500:
                    name_of_plan = "Max Yearly"
                elif price_of_plan == 200:
                    name_of_plan = "Plus Yearly"
                elif  price_of_plan == 55:
                    name_of_plan = "Max Monthly"    
                elif  price_of_plan == 25:
                    name_of_plan = "Plus Monthly"
        else:
            name_of_plan = "Free"

        return render(request, 'work_space.html', {
            'pk': pk,
            'user': user,
            'user_work_space_entries': user_work_space_entries,
            'workspace_name': workspace_name,
            'name_of_plan' : name_of_plan,
            'user_upload_files': user_upload_files,
            
        })

def user_history(request, pk):
    # Your view logic goes here
    return render(request, 'user_history.html', {'pk': pk})

def get_upload_files(request, workspace_id):
    user = User.objects.get(email=request.session['email'])   
    user_workspace_entry = WorkSpace.objects.get(id=workspace_id, user=user)
    uploadfiles_entries = Uploadfiles.objects.filter(workspace=user_workspace_entry, user=user)

    uploadfiles_data = {
        'segment_urls': [],
        'segment_texts': [],
        'upload_videos': [],
        'edited_video': None
    }
    
    for file in uploadfiles_entries:
        for i in range(1, 10):
            segment_url = getattr(file, f'segment_url_{i}', None)
            if segment_url:
                uploadfiles_data['segment_urls'].append(segment_url)
        
        for i in range(1, 10):
            segment_text = getattr(file, f'segment_text_{i}', None)
            if segment_text:
                uploadfiles_data['segment_texts'].append(segment_text)
        
        for i in range(1, 10):
            upload_video = getattr(file, f'upload_video_{i}', None)
            if upload_video:
                uploadfiles_data['upload_videos'].append(upload_video.url)

        if file.edited_video:
            uploadfiles_data['edited_video'] = file.edited_video.url

    return JsonResponse({'uploadfiles': uploadfiles_data})  

def save_feedback(request):
    if request.method == 'POST':
        feedback_message = request.POST.get('feedback_message')
        if feedback_message:
            if request.session['email']:
                user = User.objects.get(email=request.session['email'])
                Feedback.objects.create(user=user, message=feedback_message)
                return JsonResponse({'success': True, 'message': 'Feedback submitted successfully'})
            else:
                return JsonResponse({'success': False, 'message': 'User not authenticated'}, status=401)
    return JsonResponse({'success': False, 'message': 'Invalid request'}, status=400)

def delete_segment(request):
    if request.method == 'POST':
        data = json.loads(request.body)

        segment_url = data.get('segment_url')
        workspace_id = data.get('workspace_id')
       
    
    try:
        user = User.objects.get(email=request.session['email'])
        workspace_entry = WorkSpace.objects.get(id=workspace_id, user=user)

        uploadfiles_entry = Uploadfiles.objects.get(workspace=workspace_entry, user=user)

        print(uploadfiles_entry)
        for i in range(1, 10):
            if getattr(uploadfiles_entry, f'segment_url_{i}') == segment_url:
                setattr(uploadfiles_entry, f'segment_url_{i}', None)
                uploadfiles_entry.save()  
                break

        return JsonResponse({'status': 'success', 'message': 'Segment deleted successfully.'})
    
    except Uploadfiles.DoesNotExist:
        return JsonResponse({'status': 'error', 'message': 'Segment or workspace not found.'}, status=404)


@csrf_exempt
def update_segment_texts(request):
    if request.method == 'POST':
        data = json.loads(request.body)

        segment_index = data.get('segment_index')
        segment_text = data.get('segment_text')
        workspace_id = data.get('workspace_id')

        try:
            user = User.objects.get(email=request.session['email'])
            workspace_entry = WorkSpace.objects.get(id=workspace_id, user=user)

            uploadfiles_entry = Uploadfiles.objects.get(workspace=workspace_entry, user=user)

            # Update the specific segment text
            setattr(uploadfiles_entry, f'segment_text_{segment_index}', segment_text)
            uploadfiles_entry.save()

            return JsonResponse({'status': 'success', 'message': 'Segment text updated successfully.'})
        
        except Uploadfiles.DoesNotExist:
            return JsonResponse({'status': 'error', 'message': 'Segment or workspace not found.'}, status=404)

    return JsonResponse({'status': 'error', 'message': 'Invalid request method.'}, status=400)

def upload_video(request, pk):
    if request.method == 'POST':
        segment_number = int(pk)
        uploaded_file = request.FILES.get('video_upload')

        if uploaded_file:
            # Save the uploaded file to the corresponding field in the Uploadfiles model
            user = User.objects.get(email=request.session['email'])
            work_space_entry = WorkSpace.objects.filter(user=user).last()
            upload_files_entry = Uploadfiles.objects.filter(workspace=work_space_entry).last()

            # Determine the field name based on the segment number
            field_name = f'upload_video_{segment_number}'
            setattr(upload_files_entry, field_name, uploaded_file)
            upload_files_entry.save()
            
            url_field_name = f'segment_url_{segment_number}'
            setattr(upload_files_entry, url_field_name, '')
            upload_files_entry.save()

            return JsonResponse({'success': True, 'message': f'Video for Segment {segment_number} uploaded successfully'})
        else:
            return JsonResponse({'success': False, 'message': 'No file uploaded'})
    else:
        return JsonResponse({'success': False, 'message': 'Invalid request method'}) 


def generate_audio_for_mearge_upload_video(text, folder_path, gender, Eden_AI):

    headers = {
            "Authorization": f"Bearer {Eden_AI}",
            "Content-Type": "application/json"
        }

    url = "https://api.edenai.run/v2/audio/text_to_speech"
    payload = {
        "providers": "openai,amazon",
        "language": "en",
        "option": "MALE",
        "text": text,
    }

    try:
        response = requests.post(url, json=payload, headers=headers)
        result = json.loads(response.text)
        audio_url = result['openai']['audio_resource_url']
        
        if audio_url:
            audio_response = requests.get(audio_url)
            audio_data = audio_response.content
            if 'mp3' in folder_path:
                audio_output_path = folder_path
            else:
                audio_output_path = os.path.join(folder_path, "output.mp3")

            with open(audio_output_path, 'wb') as audio_file:
                audio_file.write(audio_data)

            return audio_output_path
        else:
            return None

    except requests.exceptions.RequestException as e:
        print(f"Error: {e}")
        return None
        
def merge_uploaded_videos(workspace, user, static_prefix="/home/clipgenie/public_html"):
    try:
        # Get the latest Uploadfiles entry associated with the workspace
        upload_files_entry = Uploadfiles.objects.filter(workspace=workspace).last()
        
        # Create a list to store VideoFileClip objects and text
        video_clips = []
        text_clips = []

        # Fetch video paths and text from the segment_url and segment_text fields
        for i in range(1, 10):
            field_url_name = f'segment_url_{i}'
            field_text_name = f'segment_text_{i}'
            field_name = f'upload_video_{i}'
            
            video_path = getattr(upload_files_entry, field_url_name, None)
            text = getattr(upload_files_entry, field_text_name, None)
            video_file = getattr(upload_files_entry, field_name, None)
            
            if video_path:
                # Add the static prefix to the video path
                video_path_with_prefix = static_prefix + video_path
                
                # Check if the file exists before creating VideoFileClip
                if os.path.exists(video_path_with_prefix):
                    filename = os.path.basename(video_path)
                    video_clip = VideoFileClip(video_path_with_prefix)
                    video_clips.append(video_clip)
                else:
                    print(f"File not found: {video_path_with_prefix}")

            elif video_file and os.path.exists(video_file.path):
                # Create VideoFileClip from the upload_video file
                video_clip = VideoFileClip(video_file.path)
                video_clips.append(video_clip)
            else:
                print(f"No video found in {field_name}")
            
            if text:
                text_clips.append(text)

        # Reset the text variable for the second loop
        text = None

        # Merge the text clips
        merged_text = "\n".join(text_clips)
        # Convert merged text to speech and save as audio file
        # tts = gTTS(text=merged_text, lang='en')

        audio_file_path = f'{static_prefix}/media/music/edited_audio.mp3'
        
        # Determine the output audio file path with index
        base_audio_file_path = audio_file_path.replace('.mp3', '')
        index = 1
        while os.path.exists(audio_file_path):
            audio_file_path = f"{base_audio_file_path}_{index}.mp3"
            index += 1

        # tts.save(audio_file_path)
        work_space_entry = WorkSpace.objects.filter(
                user=user
            ).last()
        gender= work_space_entry.gender

        audio_file_path = generate_audio_for_mearge_upload_video(merged_text, audio_file_path, gender, Eden_AI = settings.EDEN_AI_API_KEY)
        # Load the audio file as an AudioFileClip
        audio_clip = AudioFileClip(audio_file_path)

        # Determine the duration of the audio and video
        audio_duration = audio_clip.duration
        video_duration = sum([clip.duration for clip in video_clips])

        # Extend or trim the video to match the audio duration
        num_loops = int(audio_duration / video_duration) + 1
        final_video_clips = video_clips * num_loops
        final_video = concatenate_videoclips(final_video_clips, method="compose")

        # Trim the final video to match the audio duration
        final_video = final_video.subclip(0, audio_duration)

        # Set the audio of the final video
        final_video = final_video.set_audio(audio_clip)

        # Determine the output video file path with index
        base_output_path = f'{static_prefix}/media/videos/edited_video'
        output_path = f"{base_output_path}.mp4"

        index = 1
        while os.path.exists(output_path):
            output_path = f"{base_output_path}_{index}.mp4"
            index += 1

        # Save the merged video to a file
        final_video.write_videofile(output_path, codec="libx264", fps=24, logger=None)
        relative_path = os.path.relpath(output_path, settings.MEDIA_ROOT)
        segment_url = os.path.join(settings.MEDIA_URL, relative_path)
        work_space_entry = WorkSpace.objects.filter(
                user=user
            ).last()
        work_space_entry.edited_video_url = segment_url
        work_space_entry.save()
        # Save the video file to the edited_video field
        edited_video_file = open(output_path, "rb")
        upload_files_entry.edited_video.save(os.path.basename(output_path), File(edited_video_file))
        edited_video_file.close()
        
        # Return the path of the merged video
        return segment_url

    except Exception as e:
        print(f"Error merging uploaded videos: {e}")
        return None
        
def merge_edited_audio_video(request, pk):
    try:
        user = User.objects.get(email=request.session['email'])
        workspace = WorkSpace.objects.filter(user=user).last()

        # Call the function to merge uploaded videos
        merged_edited_video = merge_uploaded_videos(workspace, user)

        if merged_edited_video:
            # Pass the merged video path to the template
            return JsonResponse({'success': True, 'message': 'Videos merged successfully', 'merged_edited_video': merged_edited_video})
        else:
            return JsonResponse({'success': False, 'message': 'Error merging videos'})

    except User.DoesNotExist:
        return JsonResponse({'success': False, 'message': 'User does not exist'})

    except Exception as e:
        return JsonResponse({'success': False, 'message': f'Error: {e}'})

def admin_login(request):
    if request.method == "POST":
        email = request.POST.get('email')
        pswd = request.POST.get('pswd')
        
        try:
            admin_user = Admin_user.objects.get(email=email, pswd=pswd)
            # Store user information in session if needed
            request.session['email'] = admin_user.email
            request.session['pswd'] = admin_user.pswd
            messages.success(request, 'Login successful')
            return redirect('admin_side')
        except Admin_user.DoesNotExist:
            messages.error(request, 'Invalid credentials. Please try again.')

    return render(request, 'admin_login.html')

def admin_side(request):
    # Check if email and password are present in the session
    if 'email' in request.session and 'pswd' in request.session:
        email = request.session['email']
        pswd = request.session['pswd']

        try:
            admin_user = Admin_user.objects.get(email=email, pswd=pswd)
            # Fetch the most common messages in WorkSpace
            most_common_messages = WorkSpace.objects.values('message').annotate(message_count=Count('message')).order_by('-message_count')[:5]
            most_common_message_qs = WorkSpace.objects.values('message').annotate(message_count=Count('message')).order_by('-message_count')[:1]
            most_common_message = most_common_message_qs[0]['message']
            total_user_count = User.objects.count()
            total_video_count = WorkSpace.objects.count()
            video_name = WorkSpace.objects.all()
            users_with_video_count = User.objects.annotate(video_count=Count('workspace'))
            all_users_with_messages = User.objects.annotate(message_count=Count('workspace__message'))
            context = {
                'total_user_count': total_user_count,
                'total_video_count': total_video_count,
                'video_name': video_name,
                'users_with_video_count': users_with_video_count,
                'all_users_with_messages': all_users_with_messages,
                'most_common_messages': most_common_messages,
                'most_common_message' : most_common_message,
            }
            return render(request, 'admin_side.html', context)
        except Admin_user.DoesNotExist:
            # Handle the case when the Admin_side is not found
            pass

    # If email and password are not present in the session or Admin_side is not found, redirect to login
    return redirect('admin_login')

def admin_logout(request):
    if 'email' in request.session:
        del request.session['email']
    return redirect('admin_login')

def delete_entry(request, user_id):
    if request.method == 'POST':
        try:
            user = User.objects.get(pk=user_id)
            user.delete()
            # Redirect to admin side view after deletion
            return redirect('admin_side')
        except User.DoesNotExist:
            pass
    # Handle if the user does not exist or if the request method is not POST
    # Redirect to admin side view
    return redirect('admin_side')

def pricing(request):
    stripe.api_key = 'sk_test_51P64XRSGntvIRLFwswGIwpRpaoUrDA2f3QHmViSfHcPbMdofy1OUd548fs8nyH9BtMdAKapCDVwsSsvqpw8GLlEL009qoUPJQ3'
    if request.method == 'POST':
        price_id = request.POST.get('price_id')
        checkout_session = stripe.checkout.Session.create(
            payment_method_types=['card'],
            line_items=[
                {
                    'price': price_id,
                    'quantity': 1,
                },
            ],
            mode='payment',
            customer_creation='always',
            success_url=settings.REDIRECT_DOMAIN + '/payment_successful?session_id={CHECKOUT_SESSION_ID}',
            cancel_url=settings.REDIRECT_DOMAIN + '/payment_cancelled',
        )
        return redirect(checkout_session.url, code=303)
    return render(request, 'pricing.html')  


## use Stripe dummy card: 4242 4242 4242 4242
def payment_successful(request):
    stripe.api_key = 'sk_test_51P64XRSGntvIRLFwswGIwpRpaoUrDA2f3QHmViSfHcPbMdofy1OUd548fs8nyH9BtMdAKapCDVwsSsvqpw8GLlEL009qoUPJQ3'
    checkout_session_id = request.GET.get('session_id', None)
    session = stripe.checkout.Session.retrieve(checkout_session_id)
    customer = stripe.Customer.retrieve(session.customer)
    price_of_plan = int(str(session.amount_total)[:-2])
    user = User.objects.get(email=request.session['email'])
    current_date = datetime.now().date()
    # Calculate the date after num_days
    if price_of_plan == 500 or price_of_plan == 200:
        num_days = 366
    elif price_of_plan == 25 or price_of_plan == 55:
        num_days = 31
    end_date = current_date + timedelta(days=num_days)
    # Try to get the pricing instance for the user, if it exists
    pricing_instance, created = Pricing.objects.get_or_create(
        user=user,
        defaults={
            'checkout_session_id': checkout_session_id,
            'price_of_plan': price_of_plan,
            'date_of_created': current_date,
            'end_date': end_date,
        }
    )
    # If the pricing instance already existed, update its fields
    if not created:
        pricing_instance.checkout_session_id = checkout_session_id
        pricing_instance.price_of_plan = price_of_plan
        pricing_instance.date_of_created = current_date
        pricing_instance.end_date = end_date
        # You can update other fields here if needed
        pricing_instance.save()

    return render(request, 'payment_successful.html', {'customer': customer})


def payment_cancelled(request):
	stripe.api_key = 'sk_test_51P64XRSGntvIRLFwswGIwpRpaoUrDA2f3QHmViSfHcPbMdofy1OUd548fs8nyH9BtMdAKapCDVwsSsvqpw8GLlEL009qoUPJQ3'
	return render(request, 'payment_cancelled.html')


@csrf_exempt
def stripe_webhook(request):
	stripe.api_key = 'sk_test_51P64XRSGntvIRLFwswGIwpRpaoUrDA2f3QHmViSfHcPbMdofy1OUd548fs8nyH9BtMdAKapCDVwsSsvqpw8GLlEL009qoUPJQ3'
	time.sleep(10)
	payload = request.body
	signature_header = request.META['HTTP_STRIPE_SIGNATURE']
	event = None
	try:
		event = stripe.Webhook.construct_event(
			payload, signature_header, settings.STRIPE_WEBHOOK_SECRET_TEST
		)
	except ValueError as e:
		return HttpResponse(status=400)
	except stripe.error.SignatureVerificationError as e:
		return HttpResponse(status=400)
	if event['type'] == 'checkout.session.completed':
		session = event['data']['object']
		session_id = session.get('id', None)
		time.sleep(15)
		# user_payment = UserPayment.objects.get(stripe_checkout_id=session_id)
		# user_payment.payment_bool = True
		# user_payment.save()
	return HttpResponse(status=200)

def profile(request, pk):
    
    try:
        # Get the user based on the email in the session
        user = User.objects.get(email=request.session['email'])
        if user:
            name = user.name
            user_work_space_entries = WorkSpace.objects.filter(user=user)
            try:
                onboard = Onboard.objects.get(user=user)
                workspace_name = onboard.workspace_name
            except Onboard.DoesNotExist:
                # Handle the case where the onboard data does not exist
                workspace_name = None

            try:
                pricing = Pricing.objects.get(user=user)
                plan_name = pricing.plan_name
                price_of_plan = pricing.price_of_plan
                date_of_created = pricing.date_of_created
                end_date = pricing.end_date
            except:
                # Handle the case where the pricing data does not exist
                plan_name = "Free"
                price_of_plan = "Free"
                date_of_created = "Null"
                end_date = "Null"

            return render(request, 'profile_page.html', {'user': user, 'name': name, 'workspace_name': workspace_name,'plan_name': plan_name,'price_of_plan': price_of_plan,'date_of_created': date_of_created,'end_date': end_date,'user_work_space_entries': user_work_space_entries})

    except:
        # Handle the case where the user does not exist
        return redirect('login')
    
@csrf_exempt
def update_username(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        user = User.objects.get(email=request.session['email'])  # Assuming user is logged in and authenticated
        user.name = name
        user.save()
        return JsonResponse({'status': 'success'})
    return JsonResponse({'status': 'fail'}, status=400)

@csrf_exempt
def update_workspace(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        user = User.objects.get(email=request.session['email'])
        onboard = Onboard.objects.get(user=user)  # Assuming user is logged in and authenticated
        onboard.workspace_name = name
        onboard.save()
        return JsonResponse({'status': 'success'})
    return JsonResponse({'status': 'fail'}, status=400)


def trainingVideos(request):
    stripe.api_key = settings.STRIPE_API_KEY
    if request.method == 'POST':
        price_id = request.POST.get('price_id')
        checkout_session = stripe.checkout.Session.create(
            payment_method_types=['card'],
            line_items=[
                {
                    'price': price_id,
                    'quantity': 1,
                },
            ],
            mode='payment',
            customer_creation='always',
            success_url=settings.REDIRECT_DOMAIN + '/training_payment_successful?session_id={CHECKOUT_SESSION_ID}',
            cancel_url=settings.REDIRECT_DOMAIN + '/training_payment_cancelled',
        )
        return redirect(checkout_session.url, code=303)
    return render(request, 'trainingVideos.html')

def training_payment_successful(request):
    stripe.api_key = settings.STRIPE_API_KEY
    checkout_session_id = request.GET.get('session_id', None)
    session = stripe.checkout.Session.retrieve(checkout_session_id)
    customer = stripe.Customer.retrieve(session.customer)
    price_of_plan = int(str(session.amount_total)[:-2])
    user = User.objects.get(email=request.session['email'])
    current_date = datetime.now().date()
   
    pricing_instance, created = Training_Videos_Pricing.objects.get_or_create(
        user=user,
        defaults={
            'checkout_session_id': checkout_session_id,
            'price_of_plan': price_of_plan,
            'date_of_created': current_date,
        }
    )
    
    if not created:
        pricing_instance.checkout_session_id = checkout_session_id
        pricing_instance.price_of_plan = price_of_plan
        pricing_instance.date_of_created = current_date
        pricing_instance.save()

    return render(request, 'training_payment_successful.html', {'customer': customer})

def training_payment_cancelled(request):
    return render(request, 'training_payment_cancelled.html')


# start Training Page
# @login_required(login_url='login')
def training_page(request):
    if 'email' in request.session:
        try:
            user = User.objects.get(email=request.session['email'])
            try:
                training_data = Training_Videos_Pricing.objects.get(user=user)
                pricing_value_training = training_data.plan_name

                if (pricing_value_training == 'Free'):
                    base_dir = os.path.join(settings.BASE_DIR, 'myapp', 'static', 'folders', 'videos')
                    folders = [f for f in os.listdir(base_dir) if os.path.isdir(os.path.join(base_dir, f))]

                    # Sort folders: S01, S02, ..., OTHERS
                    folders.sort()
                    if 'OTHERS' in folders:
                        folders.append(folders.pop(folders.index('OTHERS')))
                    return render(request, "training.html", {'user': user, 'folders': folders})
                else:
                    return redirect('trainingVideos')

            except Training_Videos_Pricing.DoesNotExist:
                messages.error(request, 'Please Purchase Plan From this Service.')
                return redirect('trainingVideos')
        except User.DoesNotExist:
            messages.error(request, 'User not found.')
            return redirect('login')
    else:
        request.session['redirect_from'] = 'trainingVideos'
        messages.info(request, 'You need to login to access this page.')
        return redirect('login')

def get_videos(request, folder_name):
    cache_key = f'videos_{folder_name}'
    cached_data = cache.get(cache_key)
    if cached_data:
        return JsonResponse(cached_data)

    video_dir = os.path.join(settings.BASE_DIR, 'myapp', 'static', 'folders', 'videos', folder_name)
    if os.path.exists(video_dir):
        videos = [f for f in os.listdir(video_dir) if os.path.isfile(os.path.join(video_dir, f))]
        videos.sort()

        video_urls = [os.path.join(settings.STATIC_URL, 'folders', 'videos', folder_name, video) for video in videos]
        response_data = {'videos': video_urls, 'total_videos': len(videos)}
        cache.set(cache_key, response_data, timeout=60*5)  # Cache for 5 minutes
        return JsonResponse(response_data)
    return JsonResponse({'videos': [], 'total_videos': 0})

def translate_to_english(user_input_texts, detectLanguage, Eden_AI):
    headers = {
        "Authorization": f"Bearer {Eden_AI}"
    }

    url = "https://api.edenai.run/v2/translation/automatic_translation"
    payload = {
        "providers": "openai",
        "source_language": detectLanguage,
        "target_language": "en",
        "text": user_input_texts,
    }

    response = requests.post(url, json=payload, headers=headers)

    if response.status_code == 200:
        result = response.json()
        if 'openai' in result and 'text' in result['openai']:
            return result['openai']['text']
        else:
            print("Error: The expected 'text' key is not found in the response.")
            print(json.dumps(result, indent=4))  # Print the response for debugging
    else:
        print(f"Error: {response.status_code} - {response.text}")
    return None


# Translate to Detacted Language
def translate_to_detected_language(generated_text, detectLanguage, Eden_AI):
    headers = {
        "Authorization": f"Bearer {Eden_AI}"
    }

    url = "https://api.edenai.run/v2/translation/automatic_translation"
    payload = {
        "providers": "openai",
        "source_language": "en",
        "target_language": detectLanguage,
        "text": generated_text,
    }

    response = requests.post(url, json=payload, headers=headers)

    if response.status_code == 200:
        result = response.json()
        if 'openai' in result and 'text' in result['openai']:
            return result['openai']['text']
        else:
            print("Error: The expected 'text' key is not found in the response.")
            print(json.dumps(result, indent=4))  # Print the response for debugging
    else:
        print(f"Error: {response.status_code} - {response.text}")
    
    # Return None if there was an error
    return None

def prompt_optimization(translated_text, Eden_AI):
    headers = {
        "Authorization": f"Bearer {Eden_AI}"
    }
     
    url = "https://api.edenai.run/v2/text/prompt_optimization"
    payload = {
        "providers": "openai",
        "text": translated_text,
        "target_provider": "google",
    }

    response = requests.post(url, json=payload, headers=headers)
    result = json.loads(response.text)
    
    try:
        responsePromptOptimize = result['openai']['items'][0]['text']
        lines = responsePromptOptimize.split('\n')
        if len(lines) > 1:
            first_paragraph = lines[1]
        else:
            first_paragraph = responsePromptOptimize
    except (KeyError, IndexError) as e:
        # Handle the case where the expected keys or indices are not present
        first_paragraph = "Unexpected response format or missing data."
    
    return first_paragraph

def text_generation(request, pk):
    Eden_AI = settings.EDEN_AI_API_KEY

    try:
        user = User.objects.get(email=request.session['email'])
    except User.DoesNotExist:
        return redirect('login')

    if request.method == 'POST':
        textGenerationInput = request.POST.get('message', '')
        detectLanguage = language_detection(textGenerationInput, Eden_AI)

        print(detectLanguage)

        if detectLanguage == 'en':
            translated_text = textGenerationInput
        else:
            translated_text = translate_to_english(textGenerationInput, detectLanguage, Eden_AI)

        prompt_optimization_text = prompt_optimization(translated_text, Eden_AI)
        print(prompt_optimization_text)
        # user_input_text = re.sub(r'[?/!#\$]', '', prompt_optimization_text)
        response_text = generate_text(prompt_optimization_text, Eden_AI)

        if response_text:
            if detectLanguage == 'en':
                translate_text_inDetected_language = response_text
            else:
                translate_text_inDetected_language = translate_to_detected_language(response_text, detectLanguage, Eden_AI)

        print(translate_text_inDetected_language)
        response_text = translate_text_inDetected_language
        return JsonResponse({'response_text': response_text})
    return render(request, 'text_generation.html', {'user': user})
   

@csrf_exempt  # Use csrf_exempt decorator for simplicity in this example
def text_to_speech(request, pk):
    if request.method == 'POST' and request.headers.get('x-requested-with') == 'XMLHttpRequest':
        text = request.POST.get('text', '')
        Eden_AI = settings.EDEN_AI_API_KEY
        
        headers = {
            "Authorization": f"Bearer {Eden_AI}",
            "Content-Type": "application/json"
        }

        url = "https://api.edenai.run/v2/audio/text_to_speech"
        payload = {
            "providers": "openai,amazon",
            "language": "en",
            "option": "MALE",
            "text": text,
        }

        try:
            response = requests.post(url, json=payload, headers=headers)
            result = json.loads(response.text)
            
            print(result)
            audio_url = result['openai']['audio_resource_url']  # Adjust this based on the API response structure
            
            return JsonResponse({'audio_url': audio_url})
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)
    
    return render(request, 'text_to_speech.html', {'pk': pk})
 
@csrf_exempt
def upload_audio(request):
    if request.method == 'POST' and request.FILES['audioFile']:
        audio_file = request.FILES['audioFile']
        fs = FileSystemStorage(location=os.path.join(settings.BASE_DIR, 'myapp', 'static', 'speechToText'))
        filename = fs.save(audio_file.name, audio_file)
        file_url = os.path.join(settings.STATIC_URL, 'speechToText', filename)
        
        # Call Eden AI for speech-to-text conversion
        headers = {"Authorization": f"Bearer {settings.EDEN_AI_API_KEY}"}
        api_url = "https://api.edenai.run/v2/audio/speech_to_text_async"
        json_payload = {
            "providers": "deepgram/enhanced",
            "language": "en-US",
            "file_url": f"https://clipgenie.io{file_url}"
        }
        
        print(json_payload)
        response = requests.post(api_url, json=json_payload, headers=headers)
        result = json.loads(response.text)
        
        print(result)

        return JsonResponse({'file_url': file_url, 'transcription': result})
    return JsonResponse({'error': 'File not uploaded'}, status=400)

@csrf_exempt
def speech_to_text(request, pk):
    try:
        user = User.objects.get(email=request.session['email'])
    except User.DoesNotExist:
        return redirect('login')

    if pk is None:
        return redirect('index')

    return render(request, 'speech_to_text.html', {
        'pk': pk,
        'user': user,
    })

def automatic_translation(text, source_language, target_language, Eden_AI):
    headers = {"Authorization": f"Bearer {Eden_AI}"}
    url = "https://api.edenai.run/v2/translation/automatic_translation"
    payload = {
        "providers": "google,amazon",
        "source_language": source_language,
        "target_language": target_language,
        "text": text,
    }
    response = requests.post(url, json=payload, headers=headers)
    result = json.loads(response.text)
    return result['google']['text']

def language_translation(request, pk):
    Eden_AI = settings.EDEN_AI_API_KEY
    
    try:
        user = User.objects.get(email=request.session['email'])
    except User.DoesNotExist:
        return redirect('login')
    
    if request.method == 'POST':
        user_input_texts = request.POST.get('message')
        target_language = request.POST.get('target_language')
        
        detected_language = language_detection(user_input_texts, Eden_AI)
        print(detected_language)
        translated_text = automatic_translation(user_input_texts, detected_language, target_language, Eden_AI)
        print(translated_text)
        
        return JsonResponse({'translated_text': translated_text})
    
    return render(request, 'language_translation.html', {'pk': pk, 'user': user})

def text_to_image(request, pk):
    if request.method == 'POST':
        Eden_AI = settings.EDEN_AI_API_KEY
        
        try:
            user = User.objects.get(email=request.session['email'])
        except User.DoesNotExist:
            return redirect('login')
        
        prompt = request.POST.get('prompt')
        resolution = request.POST.get('resolution', '512x512')
        
        headers = {
            "Authorization": f"Bearer {Eden_AI}"
        }
        
        url = "https://api.edenai.run/v2/image/generation"
        payload = {
            "providers": ["deepai", "openai"],
            "text": prompt,
            "resolution": resolution,
        }
        
        response = requests.post(url, json=payload, headers=headers)
        result = json.loads(response.text)
        
        image_url = None
        
        # Check DeepAI response first
        if 'deepai' in result and 'items' in result['deepai']:
            image_url = result['deepai']['items'][0].get('image_resource_url', None)
        
        # If no image from DeepAI, check OpenAI response
        if not image_url and 'openai' in result and 'items' in result['openai']:
            image_url = result['openai']['items'][0].get('image_resource_url', None)
        
        if not image_url:
            return JsonResponse({'error': 'Error generating image'}, status=500)
        
        return JsonResponse({'image_url': image_url})
    
    return render(request, 'text_to_image.html', {'pk': pk})

@csrf_exempt
def email_us(request):
    if request.method == 'POST':
        form = EmailForm(request.POST)
        if form.is_valid():
            subject = form.cleaned_data['subject']
            message = form.cleaned_data['message']
            email = form.cleaned_data['email']
            send_mail(subject, message, email, [settings.SUPPORT_EMAIL])
            return JsonResponse({'success': True})
        else:
            return JsonResponse({'success': False, 'errors': form.errors})
    else:
        form = EmailForm()
    return render(request, 'email_form.html', {'form': form})

@csrf_exempt
def chatbot_response(request):
    Eden_AI = settings.EDEN_AI_API_KEY
    if request.method == 'POST':
        data = json.loads(request.body)
        user_message = data.get('message')

        headers = {
             "Authorization": f"Bearer {Eden_AI}"
        }
        url = "https://api.edenai.run/v2/text/chat"
        payload = {
            "providers": "openai/gpt-4o",
            "text": user_message,
            "chatbot_global_action": "Act as an assistant",
            "previous_history": [],
            "temperature": 0.0,
            "max_tokens": 150,
        }

        response = requests.post(url, json=payload, headers=headers)
        try:
            result = response.json()
            if 'openai/gpt-4o' in result:
                chatbot_response = result['openai/gpt-4o']['generated_text']
                return JsonResponse({'response': chatbot_response})
            else:
                return JsonResponse({'error': 'Unexpected response format from API'}, status=500)
        except json.JSONDecodeError:
            return JsonResponse({'error': 'Error decoding JSON response'}, status=500)
        except KeyError:
            return JsonResponse({'error': 'Error extracting the generated text from response'}, status=500)

@csrf_exempt
def message_to_team(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        user_message = data.get('message')
        user_email = data.get('email')  # Get the email from the request

        if not user_email:
            return JsonResponse({'error': 'Email is required'}, status=400)
        
        print(user_email)

        # Optionally, validate the email format here

        send_mail(
            'Message from Chatbot',
            user_message,
            user_email,  # Sender's email
             [settings.SUPPORT_EMAIL],
            fail_silently=False,
        )

        return JsonResponse({'response': 'Your message has been successfully sent to our team. We will respond within 24 hours. Please check your email for our reply.'})

    return JsonResponse({'error': 'Invalid request method'}, status=405)

def post_list(request):
    posts = Post.objects.filter(enabled=True, published_date__isnull=False).order_by('published_date')
    platforms = Platform.objects.filter(enabled=True, published_date__isnull=False).order_by('published_date')
    return render(request, 'blog/post_list.html', {'posts': posts, 'platforms': platforms})

def post_detail(request, pk):
    post = get_object_or_404(Post, pk=pk)
    return render(request, 'blog/post_detail.html', {'post': post}) 

def platform_detail(request, pk):
    platform = get_object_or_404(Platform, pk=pk)
    platform_id = platform.pk

    if platform_id == 1:
        blog = YouTubeBlog.objects.filter(platform=platform)        
    elif platform_id == 2:
        blog = InstagramBlog.objects.filter(platform=platform)        
    elif platform_id == 3:
        blog = TikTokBlog.objects.filter(platform=platform)        
    elif platform_id == 4:
        blog = FacebookBlog.objects.filter(platform=platform)        
    elif platform_id == 5:
        blog = LinkedInBlog.objects.filter(platform=platform)       
    else:
        blog = None
        
    platforms = Platform.objects.filter(enabled=True, published_date__isnull=False).exclude(pk=platform_id).order_by('published_date')

    return render(request, 'blog/platform_detail.html', {'platform': platform, 'blog': blog, 'platforms': platforms})

def platform_blog_detail(request, platform_id, pk):
    blog = None
    if platform_id == 1:
        blog = get_object_or_404(YouTubeBlog, pk=pk)
    elif platform_id == 2:
        blog = get_object_or_404(InstagramBlog, pk=pk)
    elif platform_id == 3:
        blog = get_object_or_404(TikTokBlog, pk=pk)
    elif platform_id == 4:
        blog = get_object_or_404(FacebookBlog, pk=pk)
    elif platform_id == 5:
        blog = get_object_or_404(LinkedInBlog, pk=pk)

    return render(request, 'blog/platform_blog_detail.html', {'blog': blog})

